package com.example.account_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccountServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
